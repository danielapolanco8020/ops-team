import pandas as pd
from pathlib import Path

from config import OUT_STEP2, OUT_STEP1, DATAFLICK_COLUMNS, DATAFLICK_DEFAULT_CHUNK
from utils.file_helpers import (
    get_excel_files, read_excel, save_excel,
    prompt_int, prompt_yes_no, make_output_path,
    print_header, print_step, print_done, print_warn, print_error,
)


def run():
    print_header("STEP 2E — DATAFLICK FORMAT")

    print(f"\n  Default chunk size: {DATAFLICK_DEFAULT_CHUNK:,} rows")
    use_default = prompt_yes_no("  Use default chunk size?", default=True)
    chunk_size  = DATAFLICK_DEFAULT_CHUNK if use_default else prompt_int(
        "  Enter chunk size", DATAFLICK_DEFAULT_CHUNK, min_val=1000
    )

    input_dir = OUT_STEP2 if list(OUT_STEP2.glob("*.xlsx")) else OUT_STEP1
    files     = get_excel_files(input_dir)

    if not files:
        print_error(f"No Excel files found in {input_dir.name}/")
        return

    print_step(f"Found {len(files)} file(s) in {input_dir.name}/")

    for f in files:
        print_step(f"Processing: {f.name}")
        df = read_excel(f)
        if df is None:
            continue

        missing = [c for c in DATAFLICK_COLUMNS if c not in df.columns]
        if missing:
            print_warn(f"  Missing columns: {', '.join(missing)} — skipping.")
            continue

        subset = df[DATAFLICK_COLUMNS].copy()

        if len(subset) > chunk_size:
            n_chunks = (len(subset) - 1) // chunk_size + 1
            print_step(f"  {len(subset):,} rows → splitting into {n_chunks} chunks of {chunk_size:,}")
            for i in range(n_chunks):
                chunk    = subset.iloc[i * chunk_size : (i + 1) * chunk_size]
                out_path = make_output_path(
                    OUT_STEP2, f.name,
                    prefix="dataflick_",
                    suffix=f"_chunk{i+1}"
                )
                save_excel(chunk, out_path)
                print_done(f"  Chunk {i+1}: {len(chunk):,} rows → {out_path.name}")
        else:
            out_path = make_output_path(OUT_STEP2, f.name, prefix="dataflick_")
            save_excel(subset, out_path)
            print_done(f"  {len(subset):,} rows → {out_path.name}")

    print_done(f"Dataflick format complete → {OUT_STEP2}")
